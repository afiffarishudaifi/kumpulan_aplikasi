<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.show')); ?> <?php echo e(trans('cruds.mkelamin.title')); ?>

    </div>

    <div class="card-body">
        <div class="form-group">
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.mkelamins.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
            <table class="table table-bordered table-striped">
                <tbody>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.mkelamin.fields.id')); ?>

                        </th>
                        <td>
                            <?php echo e($mkelamin->id); ?>

                        </td>
                    </tr>
                    <tr>
                        <th>
                            <?php echo e(trans('cruds.mkelamin.fields.nama')); ?>

                        </th>
                        <td>
                            <?php echo e($mkelamin->nama); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="form-group">
                <a class="btn btn-default" href="<?php echo e(route('admin.mkelamins.index')); ?>">
                    <?php echo e(trans('global.back_to_list')); ?>

                </a>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.relatedData')); ?>

    </div>
    <ul class="nav nav-tabs" role="tablist" id="relationship-tabs">
        <li class="nav-item">
            <a class="nav-link" href="#kelamin_m_master_siswas" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.mMasterSiswa.title')); ?>

            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#kelamin_m_gurus" role="tab" data-toggle="tab">
                <?php echo e(trans('cruds.mGuru.title')); ?>

            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane" role="tabpanel" id="kelamin_m_master_siswas">
            <?php if ($__env->exists('admin.mkelamins.relationships.kelaminMMasterSiswas', ['mMasterSiswas' => $mkelamin->kelaminMMasterSiswas])) echo $__env->make('admin.mkelamins.relationships.kelaminMMasterSiswas', ['mMasterSiswas' => $mkelamin->kelaminMMasterSiswas], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="tab-pane" role="tabpanel" id="kelamin_m_gurus">
            <?php if ($__env->exists('admin.mkelamins.relationships.kelaminMGurus', ['mGurus' => $mkelamin->kelaminMGurus])) echo $__env->make('admin.mkelamins.relationships.kelaminMGurus', ['mGurus' => $mkelamin->kelaminMGurus], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dev-cahaya\resources\views/admin/mkelamins/show.blade.php ENDPATH**/ ?>