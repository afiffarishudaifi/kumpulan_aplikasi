<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.mGuru.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.m-gurus.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="nama"><?php echo e(trans('cruds.mGuru.fields.nama')); ?></label>
                <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama" id="nama" value="<?php echo e(old('nama', '')); ?>" required>
                <?php if($errors->has('nama')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mGuru.fields.nama_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="alamat"><?php echo e(trans('cruds.mGuru.fields.alamat')); ?></label>
                <input class="form-control <?php echo e($errors->has('alamat') ? 'is-invalid' : ''); ?>" type="text" name="alamat" id="alamat" value="<?php echo e(old('alamat', '')); ?>">
                <?php if($errors->has('alamat')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('alamat')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mGuru.fields.alamat_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="kelamin_id"><?php echo e(trans('cruds.mGuru.fields.kelamin')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('kelamin') ? 'is-invalid' : ''); ?>" name="kelamin_id" id="kelamin_id" required>
                    <?php $__currentLoopData = $kelamins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('kelamin_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('kelamin')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('kelamin')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mGuru.fields.kelamin_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="nik"><?php echo e(trans('cruds.mGuru.fields.nik')); ?></label>
                <input class="form-control <?php echo e($errors->has('nik') ? 'is-invalid' : ''); ?>" type="text" name="nik" id="nik" value="<?php echo e(old('nik', '')); ?>" required>
                <?php if($errors->has('nik')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nik')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mGuru.fields.nik_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="tgl_lahir"><?php echo e(trans('cruds.mGuru.fields.tgl_lahir')); ?></label>
                <input class="form-control date <?php echo e($errors->has('tgl_lahir') ? 'is-invalid' : ''); ?>" type="text" name="tgl_lahir" id="tgl_lahir" value="<?php echo e(old('tgl_lahir')); ?>" required>
                <?php if($errors->has('tgl_lahir')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tgl_lahir')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mGuru.fields.tgl_lahir_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="tempat_lahir"><?php echo e(trans('cruds.mGuru.fields.tempat_lahir')); ?></label>
                <input class="form-control <?php echo e($errors->has('tempat_lahir') ? 'is-invalid' : ''); ?>" type="text" name="tempat_lahir" id="tempat_lahir" value="<?php echo e(old('tempat_lahir', '')); ?>" required>
                <?php if($errors->has('tempat_lahir')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('tempat_lahir')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mGuru.fields.tempat_lahir_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="mulai_bekerja"><?php echo e(trans('cruds.mGuru.fields.mulai_bekerja')); ?></label>
                <input class="form-control date <?php echo e($errors->has('mulai_bekerja') ? 'is-invalid' : ''); ?>" type="text" name="mulai_bekerja" id="mulai_bekerja" value="<?php echo e(old('mulai_bekerja')); ?>" required>
                <?php if($errors->has('mulai_bekerja')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('mulai_bekerja')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mGuru.fields.mulai_bekerja_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="status_id"><?php echo e(trans('cruds.mGuru.fields.status')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('status') ? 'is-invalid' : ''); ?>" name="status_id" id="status_id" required>
                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('status_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('status')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('status')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mGuru.fields.status_helper')); ?></span>
            </div>
            <div class="form-group">
                <label for="photo"><?php echo e(trans('cruds.mGuru.fields.photo')); ?></label>
                <div class="needsclick dropzone <?php echo e($errors->has('photo') ? 'is-invalid' : ''); ?>" id="photo-dropzone">
                </div>
                <?php if($errors->has('photo')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('photo')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mGuru.fields.photo_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    Dropzone.options.photoDropzone = {
    url: '<?php echo e(route('admin.m-gurus.storeMedia')); ?>',
    maxFilesize: 2, // MB
    acceptedFiles: '.jpeg,.jpg,.png,.gif',
    maxFiles: 1,
    addRemoveLinks: true,
    headers: {
      'X-CSRF-TOKEN': "<?php echo e(csrf_token()); ?>"
    },
    params: {
      size: 2,
      width: 4096,
      height: 4096
    },
    success: function (file, response) {
      $('form').find('input[name="photo"]').remove()
      $('form').append('<input type="hidden" name="photo" value="' + response.name + '">')
    },
    removedfile: function (file) {
      file.previewElement.remove()
      if (file.status !== 'error') {
        $('form').find('input[name="photo"]').remove()
        this.options.maxFiles = this.options.maxFiles + 1
      }
    },
    init: function () {
<?php if(isset($mGuru) && $mGuru->photo): ?>
      var file = <?php echo json_encode($mGuru->photo); ?>

          this.options.addedfile.call(this, file)
      this.options.thumbnail.call(this, file, file.preview)
      file.previewElement.classList.add('dz-complete')
      $('form').append('<input type="hidden" name="photo" value="' + file.file_name + '">')
      this.options.maxFiles = this.options.maxFiles - 1
<?php endif; ?>
    },
    error: function (file, response) {
        if ($.type(response) === 'string') {
            var message = response //dropzone sends it's own error messages in string
        } else {
            var message = response.errors.file
        }
        file.previewElement.classList.add('dz-error')
        _ref = file.previewElement.querySelectorAll('[data-dz-errormessage]')
        _results = []
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            node = _ref[_i]
            _results.push(node.textContent = message)
        }

        return _results
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dev-cahaya\resources\views/admin/mGurus/create.blade.php ENDPATH**/ ?>