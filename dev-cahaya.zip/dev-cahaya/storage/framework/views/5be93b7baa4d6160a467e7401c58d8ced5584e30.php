<div id="sidebar" class="c-sidebar c-sidebar-fixed c-sidebar-lg-show">

    <div class="c-sidebar-brand d-md-down-none">
        <a class="c-sidebar-brand-full h4" href="#">
            <?php echo e(trans('panel.site_title')); ?>

        </a>
    </div>

    <ul class="c-sidebar-nav">
        <li>
            <select class="searchable-field form-control">

            </select>
        </li>
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(route("admin.home")); ?>" class="c-sidebar-nav-link">
                <i class="c-sidebar-nav-icon fas fa-fw fa-tachometer-alt">

                </i>
                <?php echo e(trans('global.dashboard')); ?>

            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_alert_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.user-alerts.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/user-alerts") || request()->is("admin/user-alerts/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-bell c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userAlert.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master_guru_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/m-gurus*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.masterGuru.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('m_guru_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.m-gurus.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/m-gurus") || request()->is("admin/m-gurus/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-people-carry c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.mGuru.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master_siswa_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/m-master-siswas*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-users c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.masterSiswa.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('m_master_siswa_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.m-master-siswas.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/m-master-siswas") || request()->is("admin/m-master-siswas/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-users c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.mMasterSiswa.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master_kela_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/mkelas*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-hospital-alt c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.masterKela.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mkela_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.mkelas.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/mkelas") || request()->is("admin/mkelas/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-hospital-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.mkela.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master_jurusan_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/m-jurusans*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fab fa-accusoft c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.masterJurusan.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('m_jurusan_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.m-jurusans.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/m-jurusans") || request()->is("admin/m-jurusans/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.mJurusan.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tahun_ajaran_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/m-tahun-ajarans*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fab fa-yelp c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.tahunAjaran.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('m_tahun_ajaran_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.m-tahun-ajarans.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/m-tahun-ajarans") || request()->is("admin/m-tahun-ajarans/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fab fa-yelp c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.mTahunAjaran.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master_pelajaran_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/list-master-pelajarans*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-archway c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.masterPelajaran.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list_master_pelajaran_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.list-master-pelajarans.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/list-master-pelajarans") || request()->is("admin/list-master-pelajarans/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.listMasterPelajaran.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('jadwal_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/list-jadwal-pelajarans*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw far fa-clock c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.jadwal.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('list_jadwal_pelajaran_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.list-jadwal-pelajarans.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/list-jadwal-pelajarans") || request()->is("admin/list-jadwal-pelajarans/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-calendar-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.listJadwalPelajaran.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master_kelamin_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/mkelamins*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fab fa-get-pocket c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.masterKelamin.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mkelamin_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.mkelamins.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/mkelamins") || request()->is("admin/mkelamins/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.mkelamin.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('master_status_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/statuses*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-smoking c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.masterStatus.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('status_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.statuses.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/statuses") || request()->is("admin/statuses/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-align-left c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.status.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('course_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.courses.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/courses") || request()->is("admin/courses/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.course.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('lesson_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.lessons.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/lessons") || request()->is("admin/lessons/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.lesson.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('test_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.tests.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/tests") || request()->is("admin/tests/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.test.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('question_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.questions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/questions") || request()->is("admin/questions/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.question.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('question_option_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.question-options.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/question-options") || request()->is("admin/question-options/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.questionOption.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('test_result_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.test-results.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/test-results") || request()->is("admin/test-results/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.testResult.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('test_answer_access')): ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.test-answers.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/test-answers") || request()->is("admin/test-answers/*") ? "c-active" : ""); ?>">
                    <i class="fa-fw fas fa-cogs c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.testAnswer.title')); ?>

                </a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/task-statuses*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/task-tags*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/tasks*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/tasks-calendars*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-list c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.taskManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_status_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.task-statuses.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/task-statuses") || request()->is("admin/task-statuses/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-server c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.taskStatus.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_tag_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.task-tags.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/task-tags") || request()->is("admin/task-tags/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-server c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.taskTag.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('task_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.tasks.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/tasks") || request()->is("admin/tasks/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-briefcase c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.task.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tasks_calendar_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.tasks-calendars.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/tasks-calendars") || request()->is("admin/tasks-calendars/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-calendar c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.tasksCalendar.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/contact-companies*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/contact-contacts*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-phone-square c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.contactManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact_company_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.contact-companies.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/contact-companies") || request()->is("admin/contact-companies/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-building c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.contactCompany.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact_contact_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.contact-contacts.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/contact-contacts") || request()->is("admin/contact-contacts/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user-plus c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.contactContact.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_management_access')): ?>
            <li class="c-sidebar-nav-dropdown <?php echo e(request()->is("admin/permissions*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/roles*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/users*") ? "c-show" : ""); ?> <?php echo e(request()->is("admin/audit-logs*") ? "c-show" : ""); ?>">
                <a class="c-sidebar-nav-dropdown-toggle" href="#">
                    <i class="fa-fw fas fa-users c-sidebar-nav-icon">

                    </i>
                    <?php echo e(trans('cruds.userManagement.title')); ?>

                </a>
                <ul class="c-sidebar-nav-dropdown-items">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.permissions.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/permissions") || request()->is("admin/permissions/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-unlock-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.permission.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.roles.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/roles") || request()->is("admin/roles/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-briefcase c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.role.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.users.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/users") || request()->is("admin/users/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-user c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.user.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('audit_log_access')): ?>
                        <li class="c-sidebar-nav-item">
                            <a href="<?php echo e(route("admin.audit-logs.index")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/audit-logs") || request()->is("admin/audit-logs/*") ? "c-active" : ""); ?>">
                                <i class="fa-fw fas fa-file-alt c-sidebar-nav-icon">

                                </i>
                                <?php echo e(trans('cruds.auditLog.title')); ?>

                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        <?php endif; ?>
        <li class="c-sidebar-nav-item">
            <a href="<?php echo e(route("admin.systemCalendar")); ?>" class="c-sidebar-nav-link <?php echo e(request()->is("admin/system-calendar") || request()->is("admin/system-calendar/*") ? "c-active" : ""); ?>">
                <i class="c-sidebar-nav-icon fa-fw fas fa-calendar">

                </i>
                <?php echo e(trans('global.systemCalendar')); ?>

            </a>
        </li>
        <?php ($unread = \App\Models\QaTopic::unreadCount()); ?>
            <li class="c-sidebar-nav-item">
                <a href="<?php echo e(route("admin.messenger.index")); ?>" class="<?php echo e(request()->is("admin/messenger") || request()->is("admin/messenger/*") ? "c-active" : ""); ?> c-sidebar-nav-link">
                    <i class="c-sidebar-nav-icon fa-fw fa fa-envelope">

                    </i>
                    <span><?php echo e(trans('global.messages')); ?></span>
                    <?php if($unread > 0): ?>
                        <strong>( <?php echo e($unread); ?> )</strong>
                    <?php endif; ?>

                </a>
            </li>
            <?php if(file_exists(app_path('Http/Controllers/Auth/ChangePasswordController.php'))): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('profile_password_edit')): ?>
                    <li class="c-sidebar-nav-item">
                        <a class="c-sidebar-nav-link <?php echo e(request()->is('profile/password') || request()->is('profile/password/*') ? 'c-active' : ''); ?>" href="<?php echo e(route('profile.password.edit')); ?>">
                            <i class="fa-fw fas fa-key c-sidebar-nav-icon">
                            </i>
                            <?php echo e(trans('global.change_password')); ?>

                        </a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <li class="c-sidebar-nav-item">
                <a href="#" class="c-sidebar-nav-link" onclick="event.preventDefault(); document.getElementById('logoutform').submit();">
                    <i class="c-sidebar-nav-icon fas fa-fw fa-sign-out-alt">

                    </i>
                    <?php echo e(trans('global.logout')); ?>

                </a>
            </li>
    </ul>

</div><?php /**PATH C:\xampp\htdocs\dev-cahaya\resources\views/partials/menu.blade.php ENDPATH**/ ?>