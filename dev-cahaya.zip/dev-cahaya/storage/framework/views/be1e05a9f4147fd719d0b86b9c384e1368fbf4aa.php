<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.mkela.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.mkelas.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="required" for="nama"><?php echo e(trans('cruds.mkela.fields.nama')); ?></label>
                <input class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>" type="text" name="nama" id="nama" value="<?php echo e(old('nama', '')); ?>" required>
                <?php if($errors->has('nama')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('nama')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mkela.fields.nama_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="kuota"><?php echo e(trans('cruds.mkela.fields.kuota')); ?></label>
                <input class="form-control <?php echo e($errors->has('kuota') ? 'is-invalid' : ''); ?>" type="number" name="kuota" id="kuota" value="<?php echo e(old('kuota', '')); ?>" step="1" required>
                <?php if($errors->has('kuota')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('kuota')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.mkela.fields.kuota_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dev-cahaya\resources\views/admin/mkelas/create.blade.php ENDPATH**/ ?>