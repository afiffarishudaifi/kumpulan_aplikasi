<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.questionOption.title_singular')); ?>

    </div>

    <div class="card-body">
        <form method="POST" action="<?php echo e(route("admin.question-options.store")); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="question_id"><?php echo e(trans('cruds.questionOption.fields.question')); ?></label>
                <select class="form-control select2 <?php echo e($errors->has('question') ? 'is-invalid' : ''); ?>" name="question_id" id="question_id">
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e(old('question_id') == $id ? 'selected' : ''); ?>><?php echo e($entry); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('question')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('question')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.questionOption.fields.question_helper')); ?></span>
            </div>
            <div class="form-group">
                <label class="required" for="option_text"><?php echo e(trans('cruds.questionOption.fields.option_text')); ?></label>
                <input class="form-control <?php echo e($errors->has('option_text') ? 'is-invalid' : ''); ?>" type="text" name="option_text" id="option_text" value="<?php echo e(old('option_text', '')); ?>" required>
                <?php if($errors->has('option_text')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('option_text')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.questionOption.fields.option_text_helper')); ?></span>
            </div>
            <div class="form-group">
                <div class="form-check <?php echo e($errors->has('is_correct') ? 'is-invalid' : ''); ?>">
                    <input type="hidden" name="is_correct" value="0">
                    <input class="form-check-input" type="checkbox" name="is_correct" id="is_correct" value="1" <?php echo e(old('is_correct', 0) == 1 ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="is_correct"><?php echo e(trans('cruds.questionOption.fields.is_correct')); ?></label>
                </div>
                <?php if($errors->has('is_correct')): ?>
                    <div class="invalid-feedback">
                        <?php echo e($errors->first('is_correct')); ?>

                    </div>
                <?php endif; ?>
                <span class="help-block"><?php echo e(trans('cruds.questionOption.fields.is_correct_helper')); ?></span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    <?php echo e(trans('global.save')); ?>

                </button>
            </div>
        </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dev-cahaya\resources\views/admin/questionOptions/create.blade.php ENDPATH**/ ?>