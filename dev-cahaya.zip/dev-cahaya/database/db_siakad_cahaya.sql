/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 100413
 Source Host           : localhost:3306
 Source Schema         : db_siakad_cahaya

 Target Server Type    : MySQL
 Target Server Version : 100413
 File Encoding         : 65001

 Date: 22/02/2023 14:43:21
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for audit_logs
-- ----------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` bigint UNSIGNED NULL DEFAULT NULL,
  `subject_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `user_id` bigint UNSIGNED NULL DEFAULT NULL,
  `properties` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `host` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of audit_logs
-- ----------------------------
INSERT INTO `audit_logs` VALUES (1, 'created', 1, 'App\\Models\\MGuru', 1, '{\"nama\":\"Agung Widodo\",\"alamat\":null,\"kelamin_id\":\"1\",\"nik\":\"6545332154669998\",\"tgl_lahir\":\"1977-04-08\",\"tempat_lahir\":\"Kediri\",\"mulai_bekerja\":\"2021-10-05\",\"status_id\":\"1\",\"updated_at\":\"2021-10-28 07:46:46\",\"created_at\":\"2021-10-28 07:46:46\",\"id\":1,\"photo\":null,\"media\":[]}', '127.0.0.1', '2021-10-28 00:46:46', '2021-10-28 00:46:46');
INSERT INTO `audit_logs` VALUES (2, 'created', 1, 'App\\Models\\Mkela', 1, '{\"nama\":\"Kelas 1\",\"kuota\":\"30\",\"updated_at\":\"2021-10-28 07:47:39\",\"created_at\":\"2021-10-28 07:47:39\",\"id\":1}', '127.0.0.1', '2021-10-28 00:47:39', '2021-10-28 00:47:39');
INSERT INTO `audit_logs` VALUES (3, 'created', 1, 'App\\Models\\MTahunAjaran', 1, '{\"nama\":\"2021\\/2022\",\"updated_at\":\"2021-10-28 07:54:20\",\"created_at\":\"2021-10-28 07:54:20\",\"id\":1}', '127.0.0.1', '2021-10-28 00:54:20', '2021-10-28 00:54:20');
INSERT INTO `audit_logs` VALUES (4, 'created', 1, 'App\\Models\\MMasterSiswa', 1, '{\"nama\":\"Aan Rahmatullah\",\"tgl_lahir\":\"2003-04-12\",\"nisn\":\"00001\",\"angkatan_id\":\"1\",\"jurusan_id\":\"1\",\"kelas_id\":\"1\",\"kelamin_id\":\"1\",\"status_id\":\"1\",\"updated_at\":\"2021-10-28 07:55:30\",\"created_at\":\"2021-10-28 07:55:30\",\"id\":1,\"photo\":null,\"media\":[]}', '127.0.0.1', '2021-10-28 00:55:30', '2021-10-28 00:55:30');
INSERT INTO `audit_logs` VALUES (5, 'created', 2, 'App\\Models\\User', 1, '{\"name\":\"guru1\",\"email\":\"guru@gmail.com\",\"updated_at\":\"2021-10-28 07:57:31\",\"created_at\":\"2021-10-28 07:57:31\",\"id\":2}', '127.0.0.1', '2021-10-28 00:57:31', '2021-10-28 00:57:31');

-- ----------------------------
-- Table structure for contact_companies
-- ----------------------------
DROP TABLE IF EXISTS `contact_companies`;
CREATE TABLE `contact_companies`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `company_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `company_website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `company_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of contact_companies
-- ----------------------------

-- ----------------------------
-- Table structure for contact_contacts
-- ----------------------------
DROP TABLE IF EXISTS `contact_contacts`;
CREATE TABLE `contact_contacts`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `contact_first_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_last_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_phone_1` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_phone_2` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_skype` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `contact_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `company_id` bigint UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `company_fk_3871315`(`company_id`) USING BTREE,
  CONSTRAINT `company_fk_3871315` FOREIGN KEY (`company_id`) REFERENCES `contact_companies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of contact_contacts
-- ----------------------------

-- ----------------------------
-- Table structure for course_user
-- ----------------------------
DROP TABLE IF EXISTS `course_user`;
CREATE TABLE `course_user`  (
  `course_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  INDEX `course_id_fk_3880082`(`course_id`) USING BTREE,
  INDEX `user_id_fk_3880082`(`user_id`) USING BTREE,
  CONSTRAINT `course_id_fk_3880082` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `user_id_fk_3880082` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of course_user
-- ----------------------------

-- ----------------------------
-- Table structure for courses
-- ----------------------------
DROP TABLE IF EXISTS `courses`;
CREATE TABLE `courses`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `price` decimal(15, 2) NULL DEFAULT NULL,
  `is_published` tinyint(1) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `teacher_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `teacher_fk_3880076`(`teacher_id`) USING BTREE,
  CONSTRAINT `teacher_fk_3880076` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of courses
-- ----------------------------

-- ----------------------------
-- Table structure for lessons
-- ----------------------------
DROP TABLE IF EXISTS `lessons`;
CREATE TABLE `lessons`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_text` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `long_text` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `position` int NULL DEFAULT NULL,
  `is_published` tinyint(1) NULL DEFAULT 0,
  `is_free` tinyint(1) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `course_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `course_fk_3880087`(`course_id`) USING BTREE,
  CONSTRAINT `course_fk_3880087` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of lessons
-- ----------------------------

-- ----------------------------
-- Table structure for list_jadwal_pelajarans
-- ----------------------------
DROP TABLE IF EXISTS `list_jadwal_pelajarans`;
CREATE TABLE `list_jadwal_pelajarans`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `dari_jam` time(0) NOT NULL,
  `sampai_jam` time(0) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `tahun_ajaran_id` bigint UNSIGNED NOT NULL,
  `jurusan_id` bigint UNSIGNED NOT NULL,
  `pelajaran_id` bigint UNSIGNED NOT NULL,
  `guru_id` bigint UNSIGNED NOT NULL,
  `kelas_id` bigint UNSIGNED NOT NULL,
  `status_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `tahun_ajaran_fk_3880311`(`tahun_ajaran_id`) USING BTREE,
  INDEX `jurusan_fk_3880312`(`jurusan_id`) USING BTREE,
  INDEX `pelajaran_fk_3880334`(`pelajaran_id`) USING BTREE,
  INDEX `guru_fk_3880337`(`guru_id`) USING BTREE,
  INDEX `kelas_fk_3880338`(`kelas_id`) USING BTREE,
  INDEX `status_fk_3880339`(`status_id`) USING BTREE,
  CONSTRAINT `guru_fk_3880337` FOREIGN KEY (`guru_id`) REFERENCES `m_gurus` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `jurusan_fk_3880312` FOREIGN KEY (`jurusan_id`) REFERENCES `m_jurusans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `kelas_fk_3880338` FOREIGN KEY (`kelas_id`) REFERENCES `mkelas` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `pelajaran_fk_3880334` FOREIGN KEY (`pelajaran_id`) REFERENCES `list_master_pelajarans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `status_fk_3880339` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `tahun_ajaran_fk_3880311` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `m_tahun_ajarans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of list_jadwal_pelajarans
-- ----------------------------

-- ----------------------------
-- Table structure for list_master_pelajarans
-- ----------------------------
DROP TABLE IF EXISTS `list_master_pelajarans`;
CREATE TABLE `list_master_pelajarans`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `status_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `status_fk_3880323`(`status_id`) USING BTREE,
  CONSTRAINT `status_fk_3880323` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of list_master_pelajarans
-- ----------------------------
INSERT INTO `list_master_pelajarans` VALUES (1, 'Matematika', '2021-10-28 00:53:45', '2021-10-28 00:53:45', NULL, 1);

-- ----------------------------
-- Table structure for m_gurus
-- ----------------------------
DROP TABLE IF EXISTS `m_gurus`;
CREATE TABLE `m_gurus`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `nik` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_lahir` date NOT NULL,
  `tempat_lahir` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mulai_bekerja` date NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `kelamin_id` bigint UNSIGNED NOT NULL,
  `status_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `kelamin_fk_3873402`(`kelamin_id`) USING BTREE,
  INDEX `status_fk_3880047`(`status_id`) USING BTREE,
  CONSTRAINT `kelamin_fk_3873402` FOREIGN KEY (`kelamin_id`) REFERENCES `mkelamins` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `status_fk_3880047` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of m_gurus
-- ----------------------------
INSERT INTO `m_gurus` VALUES (1, 'Agung Widodo', NULL, '6545332154669998', '1977-04-08', 'Kediri', '2021-10-05', '2021-10-28 00:46:46', '2021-10-28 00:46:46', NULL, 1, 1);

-- ----------------------------
-- Table structure for m_jurusans
-- ----------------------------
DROP TABLE IF EXISTS `m_jurusans`;
CREATE TABLE `m_jurusans`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `status_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `status_fk_3872367`(`status_id`) USING BTREE,
  CONSTRAINT `status_fk_3872367` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of m_jurusans
-- ----------------------------
INSERT INTO `m_jurusans` VALUES (1, 'ipa', '2021-10-28 00:54:39', '2021-10-28 00:54:39', NULL, 1);

-- ----------------------------
-- Table structure for m_master_siswas
-- ----------------------------
DROP TABLE IF EXISTS `m_master_siswas`;
CREATE TABLE `m_master_siswas`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tgl_lahir` date NOT NULL,
  `nisn` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `angkatan_id` bigint UNSIGNED NOT NULL,
  `jurusan_id` bigint UNSIGNED NOT NULL,
  `kelas_id` bigint UNSIGNED NOT NULL,
  `kelamin_id` bigint UNSIGNED NOT NULL,
  `status_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `m_master_siswas_nisn_unique`(`nisn`) USING BTREE,
  INDEX `angkatan_fk_3872343`(`angkatan_id`) USING BTREE,
  INDEX `jurusan_fk_3872997`(`jurusan_id`) USING BTREE,
  INDEX `kelas_fk_3872998`(`kelas_id`) USING BTREE,
  INDEX `kelamin_fk_3873302`(`kelamin_id`) USING BTREE,
  INDEX `status_fk_3873386`(`status_id`) USING BTREE,
  CONSTRAINT `angkatan_fk_3872343` FOREIGN KEY (`angkatan_id`) REFERENCES `m_tahun_ajarans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `jurusan_fk_3872997` FOREIGN KEY (`jurusan_id`) REFERENCES `m_jurusans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `kelamin_fk_3873302` FOREIGN KEY (`kelamin_id`) REFERENCES `mkelamins` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `kelas_fk_3872998` FOREIGN KEY (`kelas_id`) REFERENCES `mkelas` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `status_fk_3873386` FOREIGN KEY (`status_id`) REFERENCES `statuses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of m_master_siswas
-- ----------------------------
INSERT INTO `m_master_siswas` VALUES (1, 'Aan Rahmatullah', '2003-04-12', '00001', '2021-10-28 00:55:30', '2021-10-28 00:55:30', NULL, 1, 1, 1, 1, 1);

-- ----------------------------
-- Table structure for m_tahun_ajarans
-- ----------------------------
DROP TABLE IF EXISTS `m_tahun_ajarans`;
CREATE TABLE `m_tahun_ajarans`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of m_tahun_ajarans
-- ----------------------------
INSERT INTO `m_tahun_ajarans` VALUES (1, '2021/2022', '2021-10-28 00:54:20', '2021-10-28 00:54:20', NULL);

-- ----------------------------
-- Table structure for media
-- ----------------------------
DROP TABLE IF EXISTS `media`;
CREATE TABLE `media`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  `collection_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `disk` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int UNSIGNED NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `order_column` int UNSIGNED NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `media_model_type_model_id_index`(`model_type`, `model_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of media
-- ----------------------------
INSERT INTO `media` VALUES (1, 'App\\Models\\MMasterSiswa', 1, 'photo', '617a577064f03_1617169202_4d5731ed3d700bf1f605', '617a577064f03_1617169202_4d5731ed3d700bf1f605.png', 'image/png', 'public', 17372, '[]', '{\"generated_conversions\":{\"thumb\":true,\"preview\":true}}', '[]', 1, '2021-10-28 00:55:30', '2021-10-28 00:55:41');

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 51 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES (1, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` VALUES (2, '2019_12_14_000001_create_personal_access_tokens_table', 1);
INSERT INTO `migrations` VALUES (3, '2021_05_11_000001_create_audit_logs_table', 1);
INSERT INTO `migrations` VALUES (4, '2021_05_11_000002_create_media_table', 1);
INSERT INTO `migrations` VALUES (5, '2021_05_11_000003_create_question_options_table', 1);
INSERT INTO `migrations` VALUES (6, '2021_05_11_000004_create_questions_table', 1);
INSERT INTO `migrations` VALUES (7, '2021_05_11_000005_create_tests_table', 1);
INSERT INTO `migrations` VALUES (8, '2021_05_11_000006_create_test_answers_table', 1);
INSERT INTO `migrations` VALUES (9, '2021_05_11_000007_create_lessons_table', 1);
INSERT INTO `migrations` VALUES (10, '2021_05_11_000008_create_courses_table', 1);
INSERT INTO `migrations` VALUES (11, '2021_05_11_000009_create_list_jadwal_pelajarans_table', 1);
INSERT INTO `migrations` VALUES (12, '2021_05_11_000010_create_m_gurus_table', 1);
INSERT INTO `migrations` VALUES (13, '2021_05_11_000011_create_mkelamins_table', 1);
INSERT INTO `migrations` VALUES (14, '2021_05_11_000012_create_m_jurusans_table', 1);
INSERT INTO `migrations` VALUES (15, '2021_05_11_000013_create_m_master_siswas_table', 1);
INSERT INTO `migrations` VALUES (16, '2021_05_11_000014_create_m_tahun_ajarans_table', 1);
INSERT INTO `migrations` VALUES (17, '2021_05_11_000015_create_mkelas_table', 1);
INSERT INTO `migrations` VALUES (18, '2021_05_11_000016_create_statuses_table', 1);
INSERT INTO `migrations` VALUES (19, '2021_05_11_000017_create_list_master_pelajarans_table', 1);
INSERT INTO `migrations` VALUES (20, '2021_05_11_000018_create_task_statuses_table', 1);
INSERT INTO `migrations` VALUES (21, '2021_05_11_000019_create_permissions_table', 1);
INSERT INTO `migrations` VALUES (22, '2021_05_11_000020_create_roles_table', 1);
INSERT INTO `migrations` VALUES (23, '2021_05_11_000021_create_users_table', 1);
INSERT INTO `migrations` VALUES (24, '2021_05_11_000022_create_contact_contacts_table', 1);
INSERT INTO `migrations` VALUES (25, '2021_05_11_000023_create_user_alerts_table', 1);
INSERT INTO `migrations` VALUES (26, '2021_05_11_000024_create_task_tags_table', 1);
INSERT INTO `migrations` VALUES (27, '2021_05_11_000025_create_tasks_table', 1);
INSERT INTO `migrations` VALUES (28, '2021_05_11_000026_create_contact_companies_table', 1);
INSERT INTO `migrations` VALUES (29, '2021_05_11_000027_create_test_results_table', 1);
INSERT INTO `migrations` VALUES (30, '2021_05_11_000028_create_user_user_alert_pivot_table', 1);
INSERT INTO `migrations` VALUES (31, '2021_05_11_000029_create_role_user_pivot_table', 1);
INSERT INTO `migrations` VALUES (32, '2021_05_11_000030_create_course_user_pivot_table', 1);
INSERT INTO `migrations` VALUES (33, '2021_05_11_000031_create_task_task_tag_pivot_table', 1);
INSERT INTO `migrations` VALUES (34, '2021_05_11_000032_create_permission_role_pivot_table', 1);
INSERT INTO `migrations` VALUES (35, '2021_05_11_000033_add_relationship_fields_to_list_jadwal_pelajarans_table', 1);
INSERT INTO `migrations` VALUES (36, '2021_05_11_000034_add_relationship_fields_to_test_answers_table', 1);
INSERT INTO `migrations` VALUES (37, '2021_05_11_000035_add_relationship_fields_to_list_master_pelajarans_table', 1);
INSERT INTO `migrations` VALUES (38, '2021_05_11_000036_add_relationship_fields_to_test_results_table', 1);
INSERT INTO `migrations` VALUES (39, '2021_05_11_000037_add_relationship_fields_to_m_jurusans_table', 1);
INSERT INTO `migrations` VALUES (40, '2021_05_11_000038_add_relationship_fields_to_question_options_table', 1);
INSERT INTO `migrations` VALUES (41, '2021_05_11_000039_add_relationship_fields_to_questions_table', 1);
INSERT INTO `migrations` VALUES (42, '2021_05_11_000040_add_relationship_fields_to_tests_table', 1);
INSERT INTO `migrations` VALUES (43, '2021_05_11_000041_add_relationship_fields_to_lessons_table', 1);
INSERT INTO `migrations` VALUES (44, '2021_05_11_000042_add_relationship_fields_to_courses_table', 1);
INSERT INTO `migrations` VALUES (45, '2021_05_11_000043_add_relationship_fields_to_m_gurus_table', 1);
INSERT INTO `migrations` VALUES (46, '2021_05_11_000044_add_relationship_fields_to_m_master_siswas_table', 1);
INSERT INTO `migrations` VALUES (47, '2021_05_11_000045_add_relationship_fields_to_contact_contacts_table', 1);
INSERT INTO `migrations` VALUES (48, '2021_05_11_000046_add_relationship_fields_to_tasks_table', 1);
INSERT INTO `migrations` VALUES (49, '2021_05_11_000047_create_qa_topics_table', 1);
INSERT INTO `migrations` VALUES (50, '2021_05_11_000048_create_qa_messages_table', 1);

-- ----------------------------
-- Table structure for mkelamins
-- ----------------------------
DROP TABLE IF EXISTS `mkelamins`;
CREATE TABLE `mkelamins`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mkelamins
-- ----------------------------
INSERT INTO `mkelamins` VALUES (1, 'Laki - Laki', '2021-10-28 00:44:00', '2021-10-28 00:44:00', NULL);
INSERT INTO `mkelamins` VALUES (2, 'Perempuan', '2021-10-28 00:44:11', '2021-10-28 00:44:11', NULL);
INSERT INTO `mkelamins` VALUES (3, 'Laki - Laki', '2021-10-28 00:44:21', '2021-10-28 00:44:26', '2021-10-28 00:44:26');

-- ----------------------------
-- Table structure for mkelas
-- ----------------------------
DROP TABLE IF EXISTS `mkelas`;
CREATE TABLE `mkelas`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `kuota` int NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `mkelas_nama_unique`(`nama`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of mkelas
-- ----------------------------
INSERT INTO `mkelas` VALUES (1, 'Kelas 1', 30, '2021-10-28 00:47:39', '2021-10-28 00:47:39', NULL);

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets`  (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `password_resets_email_index`(`email`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of password_resets
-- ----------------------------

-- ----------------------------
-- Table structure for permission_role
-- ----------------------------
DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE `permission_role`  (
  `role_id` bigint UNSIGNED NOT NULL,
  `permission_id` bigint UNSIGNED NOT NULL,
  INDEX `role_id_fk_3871256`(`role_id`) USING BTREE,
  INDEX `permission_id_fk_3871256`(`permission_id`) USING BTREE,
  CONSTRAINT `permission_id_fk_3871256` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `role_id_fk_3871256` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of permission_role
-- ----------------------------
INSERT INTO `permission_role` VALUES (1, 1);
INSERT INTO `permission_role` VALUES (1, 2);
INSERT INTO `permission_role` VALUES (1, 3);
INSERT INTO `permission_role` VALUES (1, 4);
INSERT INTO `permission_role` VALUES (1, 5);
INSERT INTO `permission_role` VALUES (1, 6);
INSERT INTO `permission_role` VALUES (1, 7);
INSERT INTO `permission_role` VALUES (1, 8);
INSERT INTO `permission_role` VALUES (1, 9);
INSERT INTO `permission_role` VALUES (1, 10);
INSERT INTO `permission_role` VALUES (1, 11);
INSERT INTO `permission_role` VALUES (1, 12);
INSERT INTO `permission_role` VALUES (1, 13);
INSERT INTO `permission_role` VALUES (1, 14);
INSERT INTO `permission_role` VALUES (1, 15);
INSERT INTO `permission_role` VALUES (1, 16);
INSERT INTO `permission_role` VALUES (1, 17);
INSERT INTO `permission_role` VALUES (1, 18);
INSERT INTO `permission_role` VALUES (1, 19);
INSERT INTO `permission_role` VALUES (1, 20);
INSERT INTO `permission_role` VALUES (1, 21);
INSERT INTO `permission_role` VALUES (1, 22);
INSERT INTO `permission_role` VALUES (1, 23);
INSERT INTO `permission_role` VALUES (1, 24);
INSERT INTO `permission_role` VALUES (1, 25);
INSERT INTO `permission_role` VALUES (1, 26);
INSERT INTO `permission_role` VALUES (1, 27);
INSERT INTO `permission_role` VALUES (1, 28);
INSERT INTO `permission_role` VALUES (1, 29);
INSERT INTO `permission_role` VALUES (1, 30);
INSERT INTO `permission_role` VALUES (1, 31);
INSERT INTO `permission_role` VALUES (1, 32);
INSERT INTO `permission_role` VALUES (1, 33);
INSERT INTO `permission_role` VALUES (1, 34);
INSERT INTO `permission_role` VALUES (1, 35);
INSERT INTO `permission_role` VALUES (1, 36);
INSERT INTO `permission_role` VALUES (1, 37);
INSERT INTO `permission_role` VALUES (1, 38);
INSERT INTO `permission_role` VALUES (1, 39);
INSERT INTO `permission_role` VALUES (1, 40);
INSERT INTO `permission_role` VALUES (1, 41);
INSERT INTO `permission_role` VALUES (1, 42);
INSERT INTO `permission_role` VALUES (1, 43);
INSERT INTO `permission_role` VALUES (1, 44);
INSERT INTO `permission_role` VALUES (1, 45);
INSERT INTO `permission_role` VALUES (1, 46);
INSERT INTO `permission_role` VALUES (1, 47);
INSERT INTO `permission_role` VALUES (1, 48);
INSERT INTO `permission_role` VALUES (1, 49);
INSERT INTO `permission_role` VALUES (1, 50);
INSERT INTO `permission_role` VALUES (1, 51);
INSERT INTO `permission_role` VALUES (1, 52);
INSERT INTO `permission_role` VALUES (1, 53);
INSERT INTO `permission_role` VALUES (1, 54);
INSERT INTO `permission_role` VALUES (1, 55);
INSERT INTO `permission_role` VALUES (1, 56);
INSERT INTO `permission_role` VALUES (1, 57);
INSERT INTO `permission_role` VALUES (1, 58);
INSERT INTO `permission_role` VALUES (1, 59);
INSERT INTO `permission_role` VALUES (1, 60);
INSERT INTO `permission_role` VALUES (1, 61);
INSERT INTO `permission_role` VALUES (1, 62);
INSERT INTO `permission_role` VALUES (1, 63);
INSERT INTO `permission_role` VALUES (1, 64);
INSERT INTO `permission_role` VALUES (1, 65);
INSERT INTO `permission_role` VALUES (1, 66);
INSERT INTO `permission_role` VALUES (1, 67);
INSERT INTO `permission_role` VALUES (1, 68);
INSERT INTO `permission_role` VALUES (1, 69);
INSERT INTO `permission_role` VALUES (1, 70);
INSERT INTO `permission_role` VALUES (1, 71);
INSERT INTO `permission_role` VALUES (1, 72);
INSERT INTO `permission_role` VALUES (1, 73);
INSERT INTO `permission_role` VALUES (1, 74);
INSERT INTO `permission_role` VALUES (1, 75);
INSERT INTO `permission_role` VALUES (1, 76);
INSERT INTO `permission_role` VALUES (1, 77);
INSERT INTO `permission_role` VALUES (1, 78);
INSERT INTO `permission_role` VALUES (1, 79);
INSERT INTO `permission_role` VALUES (1, 80);
INSERT INTO `permission_role` VALUES (1, 81);
INSERT INTO `permission_role` VALUES (1, 82);
INSERT INTO `permission_role` VALUES (1, 83);
INSERT INTO `permission_role` VALUES (1, 84);
INSERT INTO `permission_role` VALUES (1, 85);
INSERT INTO `permission_role` VALUES (1, 86);
INSERT INTO `permission_role` VALUES (1, 87);
INSERT INTO `permission_role` VALUES (1, 88);
INSERT INTO `permission_role` VALUES (1, 89);
INSERT INTO `permission_role` VALUES (1, 90);
INSERT INTO `permission_role` VALUES (1, 91);
INSERT INTO `permission_role` VALUES (1, 92);
INSERT INTO `permission_role` VALUES (1, 93);
INSERT INTO `permission_role` VALUES (1, 94);
INSERT INTO `permission_role` VALUES (1, 95);
INSERT INTO `permission_role` VALUES (1, 96);
INSERT INTO `permission_role` VALUES (1, 97);
INSERT INTO `permission_role` VALUES (1, 98);
INSERT INTO `permission_role` VALUES (1, 99);
INSERT INTO `permission_role` VALUES (1, 100);
INSERT INTO `permission_role` VALUES (1, 101);
INSERT INTO `permission_role` VALUES (1, 102);
INSERT INTO `permission_role` VALUES (1, 103);
INSERT INTO `permission_role` VALUES (1, 104);
INSERT INTO `permission_role` VALUES (1, 105);
INSERT INTO `permission_role` VALUES (1, 106);
INSERT INTO `permission_role` VALUES (1, 107);
INSERT INTO `permission_role` VALUES (1, 108);
INSERT INTO `permission_role` VALUES (1, 109);
INSERT INTO `permission_role` VALUES (1, 110);
INSERT INTO `permission_role` VALUES (1, 111);
INSERT INTO `permission_role` VALUES (1, 112);
INSERT INTO `permission_role` VALUES (1, 113);
INSERT INTO `permission_role` VALUES (1, 114);
INSERT INTO `permission_role` VALUES (1, 115);
INSERT INTO `permission_role` VALUES (1, 116);
INSERT INTO `permission_role` VALUES (1, 117);
INSERT INTO `permission_role` VALUES (1, 118);
INSERT INTO `permission_role` VALUES (1, 119);
INSERT INTO `permission_role` VALUES (1, 120);
INSERT INTO `permission_role` VALUES (1, 121);
INSERT INTO `permission_role` VALUES (1, 122);
INSERT INTO `permission_role` VALUES (1, 123);
INSERT INTO `permission_role` VALUES (1, 124);
INSERT INTO `permission_role` VALUES (1, 125);
INSERT INTO `permission_role` VALUES (1, 126);
INSERT INTO `permission_role` VALUES (1, 127);
INSERT INTO `permission_role` VALUES (1, 128);
INSERT INTO `permission_role` VALUES (1, 129);
INSERT INTO `permission_role` VALUES (1, 130);
INSERT INTO `permission_role` VALUES (1, 131);
INSERT INTO `permission_role` VALUES (1, 132);
INSERT INTO `permission_role` VALUES (1, 133);
INSERT INTO `permission_role` VALUES (1, 134);
INSERT INTO `permission_role` VALUES (1, 135);
INSERT INTO `permission_role` VALUES (1, 136);
INSERT INTO `permission_role` VALUES (1, 137);
INSERT INTO `permission_role` VALUES (1, 138);
INSERT INTO `permission_role` VALUES (1, 139);
INSERT INTO `permission_role` VALUES (1, 140);
INSERT INTO `permission_role` VALUES (2, 17);
INSERT INTO `permission_role` VALUES (2, 18);
INSERT INTO `permission_role` VALUES (2, 23);
INSERT INTO `permission_role` VALUES (2, 24);
INSERT INTO `permission_role` VALUES (2, 25);
INSERT INTO `permission_role` VALUES (2, 26);
INSERT INTO `permission_role` VALUES (2, 27);
INSERT INTO `permission_role` VALUES (2, 28);
INSERT INTO `permission_role` VALUES (2, 29);
INSERT INTO `permission_role` VALUES (2, 30);
INSERT INTO `permission_role` VALUES (2, 31);
INSERT INTO `permission_role` VALUES (2, 32);
INSERT INTO `permission_role` VALUES (2, 33);
INSERT INTO `permission_role` VALUES (2, 34);
INSERT INTO `permission_role` VALUES (2, 35);
INSERT INTO `permission_role` VALUES (2, 36);
INSERT INTO `permission_role` VALUES (2, 37);
INSERT INTO `permission_role` VALUES (2, 38);
INSERT INTO `permission_role` VALUES (2, 39);
INSERT INTO `permission_role` VALUES (2, 40);
INSERT INTO `permission_role` VALUES (2, 41);
INSERT INTO `permission_role` VALUES (2, 42);
INSERT INTO `permission_role` VALUES (2, 43);
INSERT INTO `permission_role` VALUES (2, 44);
INSERT INTO `permission_role` VALUES (2, 45);
INSERT INTO `permission_role` VALUES (2, 46);
INSERT INTO `permission_role` VALUES (2, 47);
INSERT INTO `permission_role` VALUES (2, 48);
INSERT INTO `permission_role` VALUES (2, 49);
INSERT INTO `permission_role` VALUES (2, 50);
INSERT INTO `permission_role` VALUES (2, 51);
INSERT INTO `permission_role` VALUES (2, 52);
INSERT INTO `permission_role` VALUES (2, 53);
INSERT INTO `permission_role` VALUES (2, 54);
INSERT INTO `permission_role` VALUES (2, 55);
INSERT INTO `permission_role` VALUES (2, 56);
INSERT INTO `permission_role` VALUES (2, 57);
INSERT INTO `permission_role` VALUES (2, 58);
INSERT INTO `permission_role` VALUES (2, 59);
INSERT INTO `permission_role` VALUES (2, 60);
INSERT INTO `permission_role` VALUES (2, 61);
INSERT INTO `permission_role` VALUES (2, 62);
INSERT INTO `permission_role` VALUES (2, 63);
INSERT INTO `permission_role` VALUES (2, 64);
INSERT INTO `permission_role` VALUES (2, 65);
INSERT INTO `permission_role` VALUES (2, 66);
INSERT INTO `permission_role` VALUES (2, 67);
INSERT INTO `permission_role` VALUES (2, 68);
INSERT INTO `permission_role` VALUES (2, 69);
INSERT INTO `permission_role` VALUES (2, 70);
INSERT INTO `permission_role` VALUES (2, 71);
INSERT INTO `permission_role` VALUES (2, 72);
INSERT INTO `permission_role` VALUES (2, 73);
INSERT INTO `permission_role` VALUES (2, 74);
INSERT INTO `permission_role` VALUES (2, 75);
INSERT INTO `permission_role` VALUES (2, 76);
INSERT INTO `permission_role` VALUES (2, 77);
INSERT INTO `permission_role` VALUES (2, 78);
INSERT INTO `permission_role` VALUES (2, 79);
INSERT INTO `permission_role` VALUES (2, 80);
INSERT INTO `permission_role` VALUES (2, 81);
INSERT INTO `permission_role` VALUES (2, 82);
INSERT INTO `permission_role` VALUES (2, 83);
INSERT INTO `permission_role` VALUES (2, 84);
INSERT INTO `permission_role` VALUES (2, 85);
INSERT INTO `permission_role` VALUES (2, 86);
INSERT INTO `permission_role` VALUES (2, 87);
INSERT INTO `permission_role` VALUES (2, 88);
INSERT INTO `permission_role` VALUES (2, 89);
INSERT INTO `permission_role` VALUES (2, 90);
INSERT INTO `permission_role` VALUES (2, 91);
INSERT INTO `permission_role` VALUES (2, 92);
INSERT INTO `permission_role` VALUES (2, 93);
INSERT INTO `permission_role` VALUES (2, 94);
INSERT INTO `permission_role` VALUES (2, 95);
INSERT INTO `permission_role` VALUES (2, 96);
INSERT INTO `permission_role` VALUES (2, 97);
INSERT INTO `permission_role` VALUES (2, 98);
INSERT INTO `permission_role` VALUES (2, 99);
INSERT INTO `permission_role` VALUES (2, 100);
INSERT INTO `permission_role` VALUES (2, 101);
INSERT INTO `permission_role` VALUES (2, 102);
INSERT INTO `permission_role` VALUES (2, 103);
INSERT INTO `permission_role` VALUES (2, 104);
INSERT INTO `permission_role` VALUES (2, 105);
INSERT INTO `permission_role` VALUES (2, 106);
INSERT INTO `permission_role` VALUES (2, 107);
INSERT INTO `permission_role` VALUES (2, 108);
INSERT INTO `permission_role` VALUES (2, 109);
INSERT INTO `permission_role` VALUES (2, 110);
INSERT INTO `permission_role` VALUES (2, 111);
INSERT INTO `permission_role` VALUES (2, 112);
INSERT INTO `permission_role` VALUES (2, 113);
INSERT INTO `permission_role` VALUES (2, 114);
INSERT INTO `permission_role` VALUES (2, 115);
INSERT INTO `permission_role` VALUES (2, 116);
INSERT INTO `permission_role` VALUES (2, 117);
INSERT INTO `permission_role` VALUES (2, 118);
INSERT INTO `permission_role` VALUES (2, 119);
INSERT INTO `permission_role` VALUES (2, 120);
INSERT INTO `permission_role` VALUES (2, 121);
INSERT INTO `permission_role` VALUES (2, 122);
INSERT INTO `permission_role` VALUES (2, 123);
INSERT INTO `permission_role` VALUES (2, 124);
INSERT INTO `permission_role` VALUES (2, 125);
INSERT INTO `permission_role` VALUES (2, 126);
INSERT INTO `permission_role` VALUES (2, 127);
INSERT INTO `permission_role` VALUES (2, 128);
INSERT INTO `permission_role` VALUES (2, 129);
INSERT INTO `permission_role` VALUES (2, 130);
INSERT INTO `permission_role` VALUES (2, 131);
INSERT INTO `permission_role` VALUES (2, 132);
INSERT INTO `permission_role` VALUES (2, 133);
INSERT INTO `permission_role` VALUES (2, 134);
INSERT INTO `permission_role` VALUES (2, 135);
INSERT INTO `permission_role` VALUES (2, 136);
INSERT INTO `permission_role` VALUES (2, 137);
INSERT INTO `permission_role` VALUES (2, 138);
INSERT INTO `permission_role` VALUES (2, 139);
INSERT INTO `permission_role` VALUES (2, 140);

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 141 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of permissions
-- ----------------------------
INSERT INTO `permissions` VALUES (1, 'user_management_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (2, 'permission_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (3, 'permission_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (4, 'permission_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (5, 'permission_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (6, 'permission_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (7, 'role_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (8, 'role_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (9, 'role_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (10, 'role_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (11, 'role_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (12, 'user_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (13, 'user_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (14, 'user_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (15, 'user_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (16, 'user_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (17, 'audit_log_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (18, 'audit_log_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (19, 'user_alert_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (20, 'user_alert_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (21, 'user_alert_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (22, 'user_alert_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (23, 'task_management_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (24, 'task_status_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (25, 'task_status_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (26, 'task_status_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (27, 'task_status_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (28, 'task_status_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (29, 'task_tag_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (30, 'task_tag_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (31, 'task_tag_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (32, 'task_tag_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (33, 'task_tag_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (34, 'task_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (35, 'task_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (36, 'task_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (37, 'task_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (38, 'task_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (39, 'tasks_calendar_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (40, 'contact_management_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (41, 'contact_company_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (42, 'contact_company_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (43, 'contact_company_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (44, 'contact_company_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (45, 'contact_company_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (46, 'contact_contact_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (47, 'contact_contact_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (48, 'contact_contact_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (49, 'contact_contact_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (50, 'contact_contact_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (51, 'master_status_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (52, 'status_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (53, 'status_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (54, 'status_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (55, 'status_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (56, 'status_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (57, 'master_kela_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (58, 'mkela_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (59, 'mkela_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (60, 'mkela_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (61, 'mkela_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (62, 'mkela_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (63, 'tahun_ajaran_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (64, 'm_tahun_ajaran_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (65, 'm_tahun_ajaran_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (66, 'm_tahun_ajaran_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (67, 'm_tahun_ajaran_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (68, 'm_tahun_ajaran_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (69, 'master_siswa_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (70, 'm_master_siswa_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (71, 'm_master_siswa_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (72, 'm_master_siswa_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (73, 'm_master_siswa_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (74, 'm_master_siswa_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (75, 'master_jurusan_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (76, 'm_jurusan_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (77, 'm_jurusan_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (78, 'm_jurusan_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (79, 'm_jurusan_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (80, 'm_jurusan_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (81, 'master_kelamin_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (82, 'mkelamin_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (83, 'mkelamin_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (84, 'mkelamin_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (85, 'mkelamin_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (86, 'mkelamin_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (87, 'master_guru_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (88, 'm_guru_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (89, 'm_guru_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (90, 'm_guru_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (91, 'm_guru_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (92, 'm_guru_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (93, 'course_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (94, 'course_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (95, 'course_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (96, 'course_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (97, 'course_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (98, 'lesson_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (99, 'lesson_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (100, 'lesson_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (101, 'lesson_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (102, 'lesson_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (103, 'test_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (104, 'test_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (105, 'test_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (106, 'test_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (107, 'test_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (108, 'question_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (109, 'question_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (110, 'question_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (111, 'question_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (112, 'question_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (113, 'question_option_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (114, 'question_option_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (115, 'question_option_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (116, 'question_option_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (117, 'question_option_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (118, 'test_result_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (119, 'test_result_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (120, 'test_result_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (121, 'test_result_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (122, 'test_result_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (123, 'test_answer_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (124, 'test_answer_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (125, 'test_answer_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (126, 'test_answer_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (127, 'test_answer_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (128, 'jadwal_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (129, 'list_jadwal_pelajaran_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (130, 'list_jadwal_pelajaran_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (131, 'list_jadwal_pelajaran_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (132, 'list_jadwal_pelajaran_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (133, 'list_jadwal_pelajaran_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (134, 'master_pelajaran_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (135, 'list_master_pelajaran_create', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (136, 'list_master_pelajaran_edit', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (137, 'list_master_pelajaran_show', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (138, 'list_master_pelajaran_delete', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (139, 'list_master_pelajaran_access', NULL, NULL, NULL);
INSERT INTO `permissions` VALUES (140, 'profile_password_edit', NULL, NULL, NULL);

-- ----------------------------
-- Table structure for personal_access_tokens
-- ----------------------------
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `last_used_at` timestamp(0) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `personal_access_tokens_token_unique`(`token`) USING BTREE,
  INDEX `personal_access_tokens_tokenable_type_tokenable_id_index`(`tokenable_type`, `tokenable_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of personal_access_tokens
-- ----------------------------

-- ----------------------------
-- Table structure for qa_messages
-- ----------------------------
DROP TABLE IF EXISTS `qa_messages`;
CREATE TABLE `qa_messages`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `topic_id` bigint UNSIGNED NOT NULL,
  `sender_id` bigint UNSIGNED NOT NULL,
  `read_at` timestamp(0) NULL DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `qa_messages_topic_id_foreign`(`topic_id`) USING BTREE,
  INDEX `qa_messages_sender_id_foreign`(`sender_id`) USING BTREE,
  CONSTRAINT `qa_messages_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `qa_messages_topic_id_foreign` FOREIGN KEY (`topic_id`) REFERENCES `qa_topics` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qa_messages
-- ----------------------------

-- ----------------------------
-- Table structure for qa_topics
-- ----------------------------
DROP TABLE IF EXISTS `qa_topics`;
CREATE TABLE `qa_topics`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `creator_id` bigint UNSIGNED NOT NULL,
  `receiver_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `qa_topics_creator_id_foreign`(`creator_id`) USING BTREE,
  INDEX `qa_topics_receiver_id_foreign`(`receiver_id`) USING BTREE,
  CONSTRAINT `qa_topics_creator_id_foreign` FOREIGN KEY (`creator_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `qa_topics_receiver_id_foreign` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of qa_topics
-- ----------------------------

-- ----------------------------
-- Table structure for question_options
-- ----------------------------
DROP TABLE IF EXISTS `question_options`;
CREATE TABLE `question_options`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `option_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_correct` tinyint(1) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `question_id` bigint UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `question_fk_3880117`(`question_id`) USING BTREE,
  CONSTRAINT `question_fk_3880117` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of question_options
-- ----------------------------

-- ----------------------------
-- Table structure for questions
-- ----------------------------
DROP TABLE IF EXISTS `questions`;
CREATE TABLE `questions`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `question_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` int NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `test_id` bigint UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `test_fk_3880109`(`test_id`) USING BTREE,
  CONSTRAINT `test_fk_3880109` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of questions
-- ----------------------------

-- ----------------------------
-- Table structure for role_user
-- ----------------------------
DROP TABLE IF EXISTS `role_user`;
CREATE TABLE `role_user`  (
  `user_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  INDEX `user_id_fk_3871265`(`user_id`) USING BTREE,
  INDEX `role_id_fk_3871265`(`role_id`) USING BTREE,
  CONSTRAINT `role_id_fk_3871265` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `user_id_fk_3871265` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of role_user
-- ----------------------------
INSERT INTO `role_user` VALUES (1, 1);
INSERT INTO `role_user` VALUES (2, 2);

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (1, 'Admin', NULL, NULL, NULL);
INSERT INTO `roles` VALUES (2, 'User', NULL, NULL, NULL);

-- ----------------------------
-- Table structure for statuses
-- ----------------------------
DROP TABLE IF EXISTS `statuses`;
CREATE TABLE `statuses`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of statuses
-- ----------------------------
INSERT INTO `statuses` VALUES (1, 'Aktif', '2021-10-28 00:45:24', '2021-10-28 00:45:24', NULL);

-- ----------------------------
-- Table structure for task_statuses
-- ----------------------------
DROP TABLE IF EXISTS `task_statuses`;
CREATE TABLE `task_statuses`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of task_statuses
-- ----------------------------
INSERT INTO `task_statuses` VALUES (1, 'Open', NULL, NULL, NULL);
INSERT INTO `task_statuses` VALUES (2, 'In progress', NULL, NULL, NULL);
INSERT INTO `task_statuses` VALUES (3, 'Closed', NULL, NULL, NULL);

-- ----------------------------
-- Table structure for task_tags
-- ----------------------------
DROP TABLE IF EXISTS `task_tags`;
CREATE TABLE `task_tags`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of task_tags
-- ----------------------------

-- ----------------------------
-- Table structure for task_task_tag
-- ----------------------------
DROP TABLE IF EXISTS `task_task_tag`;
CREATE TABLE `task_task_tag`  (
  `task_id` bigint UNSIGNED NOT NULL,
  `task_tag_id` bigint UNSIGNED NOT NULL,
  INDEX `task_id_fk_3871299`(`task_id`) USING BTREE,
  INDEX `task_tag_id_fk_3871299`(`task_tag_id`) USING BTREE,
  CONSTRAINT `task_id_fk_3871299` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `task_tag_id_fk_3871299` FOREIGN KEY (`task_tag_id`) REFERENCES `task_tags` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of task_task_tag
-- ----------------------------

-- ----------------------------
-- Table structure for tasks
-- ----------------------------
DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `due_date` date NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `status_id` bigint UNSIGNED NULL DEFAULT NULL,
  `assigned_to_id` bigint UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `status_fk_3871298`(`status_id`) USING BTREE,
  INDEX `assigned_to_fk_3871302`(`assigned_to_id`) USING BTREE,
  CONSTRAINT `assigned_to_fk_3871302` FOREIGN KEY (`assigned_to_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `status_fk_3871298` FOREIGN KEY (`status_id`) REFERENCES `task_statuses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tasks
-- ----------------------------

-- ----------------------------
-- Table structure for test_answers
-- ----------------------------
DROP TABLE IF EXISTS `test_answers`;
CREATE TABLE `test_answers`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `is_correct` tinyint(1) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `test_result_id` bigint UNSIGNED NOT NULL,
  `question_id` bigint UNSIGNED NOT NULL,
  `option_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `test_result_fk_3880131`(`test_result_id`) USING BTREE,
  INDEX `question_fk_3880132`(`question_id`) USING BTREE,
  INDEX `option_fk_3880133`(`option_id`) USING BTREE,
  CONSTRAINT `option_fk_3880133` FOREIGN KEY (`option_id`) REFERENCES `question_options` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `question_fk_3880132` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `test_result_fk_3880131` FOREIGN KEY (`test_result_id`) REFERENCES `test_results` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_answers
-- ----------------------------

-- ----------------------------
-- Table structure for test_results
-- ----------------------------
DROP TABLE IF EXISTS `test_results`;
CREATE TABLE `test_results`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `score` int NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `test_id` bigint UNSIGNED NOT NULL,
  `student_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `test_fk_3880124`(`test_id`) USING BTREE,
  INDEX `student_fk_3880125`(`student_id`) USING BTREE,
  CONSTRAINT `student_fk_3880125` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `test_fk_3880124` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of test_results
-- ----------------------------

-- ----------------------------
-- Table structure for tests
-- ----------------------------
DROP TABLE IF EXISTS `tests`;
CREATE TABLE `tests`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `is_published` tinyint(1) NULL DEFAULT 0,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  `course_id` bigint UNSIGNED NULL DEFAULT NULL,
  `lesson_id` bigint UNSIGNED NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `course_fk_3880100`(`course_id`) USING BTREE,
  INDEX `lesson_fk_3880101`(`lesson_id`) USING BTREE,
  CONSTRAINT `course_fk_3880100` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `lesson_fk_3880101` FOREIGN KEY (`lesson_id`) REFERENCES `lessons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tests
-- ----------------------------

-- ----------------------------
-- Table structure for user_alerts
-- ----------------------------
DROP TABLE IF EXISTS `user_alerts`;
CREATE TABLE `user_alerts`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `alert_text` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `alert_link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_alerts
-- ----------------------------

-- ----------------------------
-- Table structure for user_user_alert
-- ----------------------------
DROP TABLE IF EXISTS `user_user_alert`;
CREATE TABLE `user_user_alert`  (
  `user_alert_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  INDEX `user_alert_id_fk_3871282`(`user_alert_id`) USING BTREE,
  INDEX `user_id_fk_3871282`(`user_id`) USING BTREE,
  CONSTRAINT `user_alert_id_fk_3871282` FOREIGN KEY (`user_alert_id`) REFERENCES `user_alerts` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `user_id_fk_3871282` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user_user_alert
-- ----------------------------

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email_verified_at` datetime(0) NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `remember_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `deleted_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_email_unique`(`email`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'Admin', 'admin@admin.com', NULL, '$2y$10$f5bwHHgl2KAoIkT/xD9Cpef1p.GmC/GVo23FFLc7dO33OOueFpEca', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES (2, 'guru1', 'guru@gmail.com', NULL, '$2y$10$gNhpSmf7eMWhHfp1CrHOQuyOa6Bvo.NaONYVUM1Sw6y/3QLyF1vAC', NULL, '2021-10-28 00:57:31', '2021-10-28 00:57:31', NULL);

SET FOREIGN_KEY_CHECKS = 1;
